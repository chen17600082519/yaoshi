//底部bottom框架方法调用


$(function() {

	// 报名系统和教材改版鼠标悬浮效果
	$(".way-common").hover(
		function() {
			var that = this;
			Timer2 = setTimeout(function() {
				$(that).find(".mask").animate({
					width: '100%',
				}, 300);
			}, 100);

		},
		function() {
			var that = this;
			clearTimeout(Timer2);
			$(that).find(".mask").stop().animate({
				width: 0,
			}, 300);
		}
	);
	function onMap(id) {
        var mao = $('#' + id);
        if (mao.length > 0) { //判断对象是否存在   
            var pos = mao.offset().top;
            $("html,body").animate({ scrollTop: pos - 100 }, 300);
        }
    }
	// 省份锚链接
	$('.province a').click(function(){
		var id=$(this).attr('data-id');
		onMap(id);
		$(".flag").css({"display":"none"});
		$('#'+id+' .flag').css({"display":"block"});
	})

});
